#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv) 
{
	int i;
	int rep;
	
	rep = atoi(argv[1]);
	
	for(i=1; i<=rep; i++)
		printf("#%i: FSE2020-1 Adan Balcazar Elvira Diaz\n", i);

	return 0;
}
