#include <stdio.h>

int main(int argc, char **argv) 
{
	int i;
	char colores[15][15] = {"\x1b[31m","\x1b[32m","\x1b[33m","\x1b[34m","\x1b[35m",
						   "\x1b[36m","\x1b[37m","\x1b[30;1m","\x1b[31;1m","\x1b[32;1m",						
						   "\x1b[33;1m","\x1b[34;1m","\x1b[35;1m","\x1b[36;1m","\x1b[37;1m"  
						  };
	
	for(i=0; i<15; i++)
		printf("%s #%i: FSE2020-1 Adan Balcazar Elvira Diaz\n", colores[i], i+1);

	return 0;
}
